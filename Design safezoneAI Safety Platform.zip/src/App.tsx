import { useState } from "react"

type IconName =
  | "shield"
  | "arrow"
  | "bell"
  | "home"
  | "pin"
  | "book"
  | "spark"
  | "report"
  | "check"
  | "cloud"
  | "menu"
  | "close"
  | "route"
  | "signal"
  | "users"
  | "clock"

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    shield: <><path d="M12 3 5 6v5c0 4.6 2.8 8.2 7 10 4.2-1.8 7-5.4 7-10V6l-7-3Z"/><path d="M9 13c3.5 0 5.3-2.5 6-5-3.7.4-6 1.7-6 5Zm0 0c0 2 .7 3.3 2 4"/></>,
    arrow: <><path d="M5 12h14"/><path d="m14 7 5 5-5 5"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    home: <><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/></>,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    book: <><path d="M4 5a3 3 0 0 1 3-3h5v18H7a3 3 0 0 0-3 2V5Z"/><path d="M20 5a3 3 0 0 0-3-3h-5v18h5a3 3 0 0 1 3 2V5Z"/></>,
    spark: <><path d="m12 3 1.4 4.1L17 9l-3.6 1.9L12 15l-1.4-4.1L7 9l3.6-1.9L12 3Z"/><path d="m19 15 .7 2.2L22 18.5l-2.3 1.3L19 22l-.7-2.2-2.3-1.3 2.3-1.3L19 15Z"/></>,
    report: <><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.7 2.7 17a2 2 0 0 0 1.7 3h15.2a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    cloud: <path d="M17.5 19H6a4 4 0 1 1 .7-7.9A6 6 0 0 1 18.3 9a5 5 0 0 1-.8 10Z"/>,
    menu: <><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></>,
    close: <><path d="m6 6 12 12"/><path d="m18 6-12 12"/></>,
    route: <><circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19c5 0 2-8 7-8h1"/><path d="m13 8 3 3-3 3"/></>,
    signal: <><path d="M5 12.5a10 10 0 0 1 14 0"/><path d="M8.5 16a5 5 0 0 1 7 0"/><path d="M12 20h.01"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function Logo({ light = false }: { light?: boolean }) {
  return <div className={`logo ${light ? "logo-light" : ""}`}><span className="logo-mark"><Icon name="shield" size={22}/></span><span>safezone<strong>AI</strong></span></div>
}

function Landing({ onOpen, onAdmin }: { onOpen: () => void; onAdmin: () => void }) {
  const [mobile, setMobile] = useState(false)
  return <main className="landing">
    <header className="topbar">
      <Logo />
      <nav className={mobile ? "nav-open" : ""}>
        <button className="nav-link active">Home</button>
        <button className="nav-link" onClick={onOpen}>Live Alerts</button>
        <button className="nav-link" onClick={onOpen}>Safe Shelters</button>
        <button className="nav-link" onClick={onOpen}>Preparedness</button>
      </nav>
      <div className="nav-actions"><button className="admin-link" onClick={onAdmin}>Admin portal</button><button className="primary nav-cta" onClick={onOpen}>Open Safety Dashboard <Icon name="arrow" size={17}/></button></div>
      <button className="icon-button menu-button" onClick={() => setMobile(!mobile)} aria-label="Toggle menu"><Icon name={mobile ? "close" : "menu"}/></button>
    </header>

    <section className="hero">
      <div className="hero-copy">
        <div className="eyebrow"><span className="pulse-dot"/> Safety, made clear</div>
        <h1>When uncertainty rises, find your <em>safe zone.</em></h1>
        <p className="hero-lede">Local alerts, trusted safety guidance, and essential resources — even when you’re offline.</p>
        <div className="hero-actions">
          <button className="primary large" onClick={onOpen}>Explore Safety Dashboard <Icon name="arrow" size={18}/></button>
          <button className="secondary large" onClick={onOpen}><Icon name="book" size={18}/> View Emergency Guide</button>
        </div>
        <div className="trust-note"><span><Icon name="check" size={15}/></span> Built for clarity in critical moments</div>
      </div>
      <div className="hero-visual">
        <img src="https://images.unsplash.com/photo-1578517929034-db013fd86597?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=85&w=1400" alt="Misty green Sri Lankan highlands"/>
        <div className="image-shade"/>
        <div className="location-chip"><span><Icon name="pin" size={17}/></span><div><small>Your area</small><strong>Kandy, Sri Lanka</strong></div></div>
        <div className="offline-card">
          <div className="offline-icon"><Icon name="cloud" size={21}/><span/></div>
          <div><strong>Ready, even offline</strong><p>12 essential guides saved on this device</p></div>
          <span className="ready"><Icon name="check" size={14}/></span>
        </div>
        <div className="calm-card"><span>LOCAL RISK LEVEL</span><strong><i/> Low</strong><small>Updated 8 min ago</small></div>
      </div>
    </section>

    <section className="feature-strip">
      {[
        ["bell","Local Risk Alerts","Know what’s happening nearby"],
        ["home","Nearby Safe Shelters","Find help and directions"],
        ["book","Offline Emergency Guide","Critical steps, always available"],
        ["spark","AI Safety Assistant","Clear answers when online"],
      ].map(([icon,title,text]) => <div className="feature" key={title}><span><Icon name={icon as IconName}/></span><div><strong>{title}</strong><p>{text}</p></div></div>)}
    </section>
    <p className="photo-credit">Photo by Anton Lecock on Unsplash</p>
  </main>
}

const nav = [
  ["home","Overview"],["bell","Live alerts"],["pin","Safe shelters"],["book","Emergency guide"],
  ["spark","AI assistant"],["report","Report incident"],["check","Preparedness"],
] as [IconName,string][]

function Dashboard({ onExit }: { onExit: () => void }) {
  const [active, setActive] = useState("Overview")
  const [online, setOnline] = useState(true)
  const [drawer, setDrawer] = useState(false)
  return <div className="app-shell">
    <aside className={drawer ? "side open" : "side"}>
      <div className="side-head"><Logo light/><button className="side-close" onClick={() => setDrawer(false)}><Icon name="close"/></button></div>
      <div className="side-location"><span><Icon name="pin" size={18}/></span><div><small>Monitoring area</small><strong>Kandy, LK</strong></div></div>
      <nav className="side-nav">{nav.map(([icon,label]) => <button key={label} className={active === label ? "active" : ""} onClick={() => {setActive(label); setDrawer(false)}}><Icon name={icon}/><span>{label}</span>{label === "Live alerts" && <b>2</b>}</button>)}</nav>
      <div className="side-saved"><Icon name="cloud"/><div><strong>Offline-ready</strong><small>12 guides saved</small></div><Icon name="check" size={16}/></div>
      <button className="back-link" onClick={onExit}>← Back to website</button>
    </aside>
    <section className="main-panel">
      <header className="dash-top">
        <button className="icon-button dash-menu" onClick={() => setDrawer(true)}><Icon name="menu"/></button>
        <div><span className="mobile-logo"><Logo/></span><p>Tuesday, 20 August</p></div>
        <div className="top-actions">
          <button className={`connection ${online ? "" : "offline"}`} onClick={() => setOnline(!online)}><i/><Icon name={online ? "signal" : "cloud"} size={16}/>{online ? "Online" : "Offline"}</button>
          <button className="icon-button"><Icon name="bell"/><span className="notification"/></button>
          <div className="avatar">SK</div>
        </div>
      </header>
      {!online && <div className="offline-banner"><Icon name="cloud"/><div><strong>You’re offline. Your saved safety resources are still available.</strong><span>Live alerts and AI assistance will resume when you reconnect.</span></div><button onClick={() => setActive("Emergency guide")}>View saved guides</button></div>}
      {active === "Overview" ? <Overview setActive={setActive}/> : <Screen name={active} online={online}/>}
    </section>
  </div>
}

function Overview({ setActive }: { setActive: (s:string) => void }) {
  return <div className="dashboard-content">
    <div className="welcome"><div><p className="kicker">GOOD MORNING, SAM</p><h2>Your safety, all in one place.</h2><p>Here’s the latest for Kandy and your saved locations.</p></div><div className="updated"><Icon name="clock" size={15}/> Updated 8 min ago</div></div>
    <div className="dashboard-grid">
      <div className="main-column">
        <section className="risk-card card">
          <div className="risk-heading"><div><span className="section-label">LOCAL RISK SUMMARY</span><h3>Kandy District</h3></div><span className="normal-badge"><i/> Normal</span></div>
          <p>No active critical warnings in your area. Light rain is forecast for this afternoon.</p>
          <div className="risk-stats">
            <div><span className="weather-icon">22°</span><small>WEATHER</small><strong>Light rain</strong></div>
            <div><span className="risk-icon rain">〽</span><small>FLOOD RISK</small><strong>Low</strong></div>
            <div><span className="risk-icon wind">≈</span><small>WIND</small><strong>12 km/h</strong></div>
          </div>
          <button className="text-button" onClick={() => setActive("Live alerts")}>View local details <Icon name="arrow" size={16}/></button>
        </section>
        <section className="section-block">
          <div className="section-title"><div><span className="section-label">NEAR YOU</span><h3>Nearby safe shelters</h3></div><button className="text-button" onClick={() => setActive("Safe shelters")}>View map <Icon name="arrow" size={16}/></button></div>
          <div className="shelter-list">
            <div className="shelter card"><span className="shelter-icon"><Icon name="home"/></span><div className="shelter-info"><strong>Dharmaraja College Hall</strong><p><Icon name="pin" size={14}/> Lake Round · 1.2 km away</p><span className="open-status"><i/> Open · 68 spaces</span></div><button className="directions"><Icon name="route" size={17}/> Directions</button></div>
            <div className="shelter card"><span className="shelter-icon"><Icon name="home"/></span><div className="shelter-info"><strong>Kandy Community Centre</strong><p><Icon name="pin" size={14}/> Peradeniya Rd · 2.6 km away</p><span className="limited-status"><i/> Limited · 14 spaces</span></div><button className="directions"><Icon name="route" size={17}/> Directions</button></div>
          </div>
        </section>
        <section className="section-block updates">
          <div className="section-title"><div><span className="section-label">COMMUNITY</span><h3>Recent updates</h3></div></div>
          <div className="card update-row"><span className="update-avatar"><Icon name="users"/></span><div><strong>Road clear near Ampitiya junction</strong><p>Shared by a verified community responder</p></div><small>24 min</small></div>
        </section>
      </div>
      <div className="right-column">
        <section><div className="section-title"><div><span className="section-label">NEED HELP?</span><h3>Quick actions</h3></div></div>
          <div className="quick-grid">
            <button className="quick urgent" onClick={() => setActive("Report incident")}><span><Icon name="report"/></span><strong>Report an incident</strong><small>Share what you see</small><Icon name="arrow" size={17}/></button>
            <button className="quick" onClick={() => setActive("Emergency guide")}><span><Icon name="book"/></span><strong>Emergency guide</strong><small>Available offline</small><Icon name="arrow" size={17}/></button>
            <button className="quick" onClick={() => setActive("Safe shelters")}><span><Icon name="pin"/></span><strong>Find safe shelter</strong><small>2 open nearby</small><Icon name="arrow" size={17}/></button>
            <button className="quick ai" onClick={() => setActive("AI assistant")}><span><Icon name="spark"/></span><strong>Ask safezoneAI</strong><small>Get clear guidance</small><Icon name="arrow" size={17}/></button>
          </div>
        </section>
        <section className="prep card">
          <div className="prep-head"><span className="round-icon"><Icon name="check"/></span><div><span className="section-label">PREPAREDNESS</span><h3>Your readiness plan</h3></div><strong>72%</strong></div>
          <div className="progress"><span/></div>
          <p>3 steps left to complete your household plan.</p>
          <button className="secondary full" onClick={() => setActive("Preparedness")}>Continue checklist <Icon name="arrow" size={16}/></button>
        </section>
        <section className="map-card card">
          <div className="map-art"><span className="road r1"/><span className="road r2"/><span className="road r3"/><span className="map-pin p1"><Icon name="home" size={15}/></span><span className="map-pin p2"><Icon name="home" size={15}/></span><span className="you-dot"/></div>
          <div><strong>Your safety map</strong><p>2 shelters and 1 medical point nearby</p></div>
        </section>
      </div>
    </div>
    <p className="disclaimer">Illustrative safety data — not real-time verified information.</p>
  </div>
}

function Screen({ name, online }: { name: string; online: boolean }) {
  if (name === "Report incident") return <ReportScreen online={online}/>
  if (name === "AI assistant") return <AssistantScreen online={online}/>
  const info: Record<string,{title:string;sub:string;icon:IconName}> = {
    "Live alerts": {title:"Live alerts",sub:"Verified updates and advisories for your monitored areas.",icon:"bell"},
    "Safe shelters": {title:"Safe shelters",sub:"Find open shelters, services, and the safest route nearby.",icon:"pin"},
    "Emergency guide": {title:"Offline emergency guide",sub:"Trusted instructions saved and ready when connectivity is not.",icon:"book"},
    "Preparedness": {title:"Preparedness checklist",sub:"Small steps today can make a critical difference tomorrow.",icon:"check"},
  }
  const d = info[name]
  return <div className="screen-content">
    <div className="screen-heading"><span><Icon name={d.icon}/></span><div><h2>{d.title}</h2><p>{d.sub}</p></div></div>
    {name === "Live alerts" && <><div className="alert-card warning"><span><Icon name="report"/></span><div><small>WEATHER ADVISORY · ILLUSTRATIVE</small><h3>Heavy rain watch for Central Province</h3><p>Periods of heavy rain may increase landslide risk in elevated areas. Monitor local updates.</p><div className="meta"><Icon name="clock" size={15}/> Updated 18 min ago · Live information</div></div><button className="secondary">View details</button></div><div className="alert-card normal"><span><Icon name="check"/></span><div><small>AREA STATUS</small><h3>No critical alerts for Kandy</h3><p>Normal conditions are currently reported in your immediate area.</p></div></div></>}
    {name === "Safe shelters" && <div className="split-view"><div className="map-large"><div className="map-art"><span className="road r1"/><span className="road r2"/><span className="road r3"/><span className="map-pin p1"><Icon name="home" size={17}/></span><span className="map-pin p2"><Icon name="home" size={17}/></span><span className="you-dot"/></div></div><div className="shelter-stack">{["Dharmaraja College Hall","Kandy Community Centre","Hillwood Medical Point"].map((x,i)=><div className="card compact-shelter" key={x}><span><Icon name={i===2?"report":"home"}/></span><div><strong>{x}</strong><p>{i+1}.2 km away · {i===1?"Limited":"Open"}</p></div><button><Icon name="route"/></button></div>)}</div></div>}
    {name === "Emergency guide" && <><div className="saved-notice"><Icon name="cloud"/><div><strong>Saved on this device</strong><p>12 guides available without internet · Last updated today, 08:42</p></div><span><Icon name="check"/></span></div><div className="guide-grid">{["Flood safety","Landslide warning signs","Earthquake response","Emergency first aid","Evacuation checklist","Family communication plan"].map((g,i)=><button className="guide card" key={g}><span><Icon name={i%2?"report":"book"}/></span><strong>{g}</strong><small><Icon name="check" size={14}/> Saved offline</small><Icon name="arrow" size={18}/></button>)}</div></>}
    {name === "Preparedness" && <div className="checklist card">{["Save emergency contacts","Prepare a 3-day water supply","Pack essential medicines","Choose a family meeting point","Download offline safety guides"].map((x,i)=><label key={x}><input type="checkbox" defaultChecked={i<3}/><span><Icon name="check" size={15}/></span><div><strong>{x}</strong><small>{i<3?"Completed":"Recommended next step"}</small></div></label>)}</div>}
  </div>
}

function AssistantScreen({ online }: { online:boolean }) {
  return <div className="screen-content assistant-screen"><div className="screen-heading"><span><Icon name="spark"/></span><div><h2>AI safety assistant</h2><p>Practical guidance, explained clearly for your situation.</p></div></div>
    {!online ? <div className="ai-offline card"><Icon name="cloud" size={30}/><h3>AI assistance needs a connection</h3><p>Your saved emergency instructions are still available offline. For immediate danger, contact local emergency services when possible.</p><button className="primary">Open saved emergency guide</button></div> :
    <div className="chat-layout"><div className="chat card"><div className="message ai-message"><span><Icon name="spark"/></span><div><strong>safezoneAI</strong><p>I can help explain alerts, prepare an emergency kit, or give concise steps for floods, landslides, and other hazards. What do you need?</p></div></div><div className="suggestions"><button>Explain today’s rain advisory</button><button>Help me pack an emergency kit</button><button>What are landslide warning signs?</button></div><div className="chat-input"><input placeholder="Ask a safety question…"/><button><Icon name="arrow"/></button></div></div><aside className="ai-note"><Icon name="shield"/><strong>Guidance, not emergency dispatch</strong><p>safezoneAI provides preparedness information. It does not contact emergency services.</p></aside></div>}
  </div>
}

function ReportScreen({ online }: { online:boolean }) {
  const [sent,setSent]=useState(false)
  if(sent) return <div className="screen-content"><div className="success-state card"><span><Icon name={online?"check":"cloud"} size={30}/></span><h2>{online?"Report submitted":"Report saved on this device"}</h2><p>{online?"Your report has been received for review.":"You’re offline. This report has not reached emergency services and is waiting to sync."}</p><div className={online?"status-pill":"status-pill pending"}>{online?"Submitted":"Waiting to sync"}</div><button className="secondary" onClick={()=>setSent(false)}>Create another report</button></div></div>
  return <div className="screen-content report-screen"><div className="screen-heading"><span className="red"><Icon name="report"/></span><div><h2>Report an incident</h2><p>Share clear, factual information. If there is immediate danger, contact emergency services.</p></div></div><form className="report-form card" onSubmit={e=>{e.preventDefault();setSent(true)}}><div className="form-row"><label>Incident type<select required defaultValue=""><option value="" disabled>Select incident</option><option>Flooding</option><option>Landslide</option><option>Fire</option><option>Blocked road</option><option>Other</option></select></label><label>Severity<select><option>Low — monitoring</option><option>Warning — action needed</option><option>Critical — immediate danger</option></select></label></div><label>Description<textarea rows={4} placeholder="What is happening? Include visible risks and who may be affected."/></label><label>Location<input placeholder="Use current location or enter manually"/></label><label className="upload"><span><Icon name="report"/></span><strong>Add a photo</strong><small>Optional · JPG or PNG</small></label><div className="form-foot"><p>{online?<><i className="online-dot"/> You’re online — report will be submitted.</>:<><i className="pending-dot"/> Offline — report will only be saved locally.</>}</p><button className="primary" type="submit">{online?"Submit report":"Save report locally"} <Icon name="arrow" size={17}/></button></div></form></div>
}

function AdminDashboard({ onExit }: { onExit: () => void }) {
  const [tab,setTab]=useState("Overview")
  const [confirmed,setConfirmed]=useState(false)
  const tabs:[IconName,string][]=[["home","Overview"],["bell","Alerts"],["report","Incidents"],["pin","Shelters"]]
  const reports=[["REF-1042","Flooding","Peradeniya","In review"],["REF-1041","Blocked road","Ampitiya","New"],["REF-1038","Landslide risk","Hanthana","Assigned"],["LOCAL-007","Tree fall","Katugastota","Waiting to sync"]]
  return <div className="admin-app">
    <aside className="admin-sidebar"><Logo light/><small>ADMIN CONTROL CENTRE</small><nav>{tabs.map(([icon,label])=><button className={tab===label?"active":""} onClick={()=>setTab(label)} key={label}><Icon name={icon}/>{label}{label==="Incidents"&&<b>4</b>}</button>)}</nav><div className="system-ok"><Icon name="shield"/><span><strong>System operational</strong><small>Synced 2 min ago</small></span></div><button className="admin-back" onClick={onExit}>← Back to website</button></aside>
    <main className="admin-main"><header><div><small>SAFEZONE OPERATIONS</small><strong>{tab}</strong></div><div><span>Kandy District Admin</span><div className="avatar">AD</div></div></header><div className="admin-body">
      <div className="welcome"><div><p className="kicker">OPERATIONS OVERVIEW</p><h2>Good morning, Admin.</h2><p>Monitor alerts, reports, and shelter readiness from one place.</p></div><div className="updated"><Icon name="clock" size={15}/> Updated 2 min ago</div></div>
      <p className="sample-label">Illustrative sample data — not verified real-time emergency information.</p>
      {tab==="Overview"&&<><div className="admin-stats">{[["bell","Active alerts","3","1 critical"],["report","Reported incidents","18","+5 today"],["home","Available shelters","12","84% capacity"],["cloud","Pending reports","4","Awaiting review"]].map(([icon,label,value,note],i)=><button className="card admin-stat" key={label} onClick={()=>setTab(i===0?"Alerts":i===2?"Shelters":"Incidents")}><span className={`stat-icon stat-${i}`}><Icon name={icon as IconName}/></span><div><small>{label}</small><strong>{value}</strong><p>{note}</p></div><Icon name="arrow" size={16}/></button>)}</div><div className="admin-grid"><AlertList/><section className="card activity"><div className="section-title"><div><span className="section-label">AUDIT TRAIL</span><h3>Recent activity</h3></div></div>{[["Alert updated","Heavy rain watch","12 min"],["Report assigned","Flooding · REF-1042","28 min"],["Shelter updated","Dharmaraja Hall","45 min"],["Alert resolved","Wind advisory","1 hr"]].map(x=><div className="activity-row" key={x[1]}><i/><span><strong>{x[0]}</strong><small>{x[1]}</small></span><time>{x[2]}</time></div>)}</section></div></>}
      {tab==="Alerts"&&<div className="admin-grid"><section className="card alert-form"><div className="section-title"><div><span className="section-label">NEW ADVISORY</span><h3>Create an alert</h3></div></div>{confirmed?<div className="confirmation"><Icon name="check" size={30}/><h3>Alert draft created</h3><p>Review and publish after verification.</p><button className="secondary" onClick={()=>setConfirmed(false)}>Create another</button></div>:<form onSubmit={e=>{e.preventDefault();setConfirmed(true)}}><label>Alert title<input required placeholder="e.g. Heavy rain advisory"/></label><div className="form-row"><label>Severity<select><option>Normal</option><option>Warning</option><option>Critical</option></select></label><label>Affected area<input placeholder="District or area"/></label></div><label>Public instructions<textarea rows={4} placeholder="Write clear safety steps…"/></label><button className="primary" type="submit">Create alert draft <Icon name="arrow" size={16}/></button></form>}</section><AlertList/></div>}
      {tab==="Incidents"&&<section className="card admin-table"><div className="section-title"><div><span className="section-label">INCOMING REPORTS</span><h3>Incident report queue</h3></div><button className="secondary small-btn">Filter</button></div><div className="table-head"><span>Reference</span><span>Incident</span><span>Area</span><span>Status</span><span>Action</span></div>{reports.map((x,i)=><div className="table-row" key={x[0]}><strong>{x[0]}</strong><span>{x[1]}</span><span>{x[2]}</span><em className={`report-state state-${i}`}>{x[3]}</em><button>View <Icon name="arrow" size={14}/></button></div>)}</section>}
      {tab==="Shelters"&&<section className="card admin-table"><div className="section-title"><div><span className="section-label">FACILITY READINESS</span><h3>Manage shelters</h3></div><button className="primary small-btn">+ Add shelter</button></div><div className="shelter-manage">{[["Dharmaraja College Hall","Open","68 spaces"],["Kandy Community Centre","Limited","14 spaces"],["Hillwood Medical Point","Open","Medical support"],["Peradeniya School Hall","Closed","Maintenance"]].map(([name,status,note])=><div key={name}><span><Icon name="home"/></span><div><strong>{name}</strong><small>{note}</small></div><em className={status.toLowerCase()}>{status}</em><button className="secondary small-btn">Edit</button></div>)}</div></section>}
    </div></main>
  </div>
}

function AlertList(){
  return <section className="card admin-table"><div className="section-title"><div><span className="section-label">ACTIVE NOW</span><h3>Alert management</h3></div><button className="primary small-btn">+ New alert</button></div>{[["critical","Critical","Landslide evacuation notice","Hanthana · 24 min"],["warning","Warning","Heavy rain watch","Central Province · 1 hr"],["normal","Normal","Reservoir level update","Kandy District · 3 hr"]].map(([kind,status,title,meta])=><div className="alert-row" key={title}><em className={kind}>{status}</em><div><strong>{title}</strong><small>{meta}</small></div><button className="secondary small-btn">Edit</button></div>)}</section>
}

export default function App() {
  const [view, setView] = useState<"landing"|"user"|"admin">("landing")
  if(view==="user") return <Dashboard onExit={()=>setView("landing")}/>
  if(view==="admin") return <AdminDashboard onExit={()=>setView("landing")}/>
  return <Landing onOpen={()=>setView("user")} onAdmin={()=>setView("admin")}/>
}
